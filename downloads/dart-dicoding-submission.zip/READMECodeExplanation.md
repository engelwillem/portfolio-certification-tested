# Dart Fundamentals Submission (Dicoding) — Exams 1–4

## Overview
This repository contains my solutions for a **Dicoding Dart submission** (command-line project) consisting of **4 exams**, each with **3 TODO tasks**.  
The starter/template files were provided by Dicoding, and I implemented the required TODOs to demonstrate core Dart competencies.

## What I built
### Exam 1 — Dart Fundamentals
- Declared and returned basic variables (`String`, `int`, `bool`) via `studentInfo()`.
    - Uses the environment variable `NAME` for the `name` value (as required by the provided tests).
- Implemented `circleArea(r)`:
    - Returns `double` area of a circle.
    - Handles edge case `r < 0` → returns `0.0`.
- Implemented `parseAndAddOne(input)`:
    - Returns `null` if input is `null`.
    - Parses `String → int`, returns `value + 1`.
    - Throws `Exception('Input harus berupa angka')` on invalid input.

### Exam 2 — Control Flow
- Implemented `oddOrEven(number)` to return `"Genap"` or `"Ganjil"`.
- Implemented `createListOneToX(x)`:
    - Returns `[]` if `x < 1`, otherwise returns `[1..x]`.
- Implemented `getStars(n)` to generate a descending star pattern using loops and newline separators.

### Exam 3 — Collections
- Implemented `uniqueElement(list)` to convert `List<int>` into a `Set` of unique values.
- Built `Map<String, String>` for futsal positions with `buildFutsalPlayersMap()`.
- Updated a specific key (`Pivot`) via `updatePivotPlayer()`.

### Exam 4 — OOP + Async
- Created `DicodingStudent` class with:
    - Constructor, fields (`fullName`, `age`)
    - `incrementAge()` returning `age + 1`
    - `getStudentInfo()` returning a formatted string after a **3-second delay** using `Future.delayed`
- Implemented `createStudent()` to return a valid `DicodingStudent` instance (name: letters only, min 3 chars; age: 15–99).

## Tech stack
- **Dart SDK**: `^3.10.4`
- **Testing**: `package:test`
- **Static analysis**: `analyzer`
- **Linting**: `lints`

## How to run
### Prerequisites
- Dart SDK installed (Dart 3.x recommended)

### Update Dart & Install dependencies
```bash
dart --version
dart pub get

```

### Run all tests (Windows PowerShell)
```powershell
$env:NAME="Your Name"
dart test
```

